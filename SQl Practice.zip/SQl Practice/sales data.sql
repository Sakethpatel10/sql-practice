create table department(dept_id int primary key auto_increment,dept_name 
varchar (100) unique not null);

create table employee(emp_id int primary key auto_increment,
emp_name varchar(100),salary 
varchar(100),  foreign key(dept_id) references
 department(dept_id));
 
 create table sales(sales_id int primary key auto_increment  ,product_name 
 Varchar(100) ,sales_date datetime, quantity int ,price int);
 drop table sales;
 insert into sales(product_name,sales_date ,quantity,price )
 values("washing machine",current_timestamp(),1,234.33);
 
 
 insert into sales(product_name,sales_date ,quantity,price )
 values("laptop",current_timestamp(),1,23333.33);
 
 insert into sales(product_name,sales_date ,quantity,price )
 values("mobile",current_timestamp(),1,3333.33);
 
 
 
 select * from sales
 order by sales_id desc
 limit 1;
 
 select distinct product_name from sales;
 select product_name from sales;
 
alter table sales add discount decimal(5,2);
 
insert into sales(product_name,sales_date ,quantity,price,discount )
 values("mobile",current_timestamp(),1,3333.33,10);
 insert into sales(product_name,sales_date ,quantity,price,discount )
 values("photo frame",current_timestamp(),1,350.33,10);
 
alter table sales drop column discount;
 
alter table sales add  qty_available decimal(5,2);

alter table sales modify column qty_available int;

select * from sales;

select * from sales order by price desc;
select * from sales where price>=4000;
select * from sales where price between 2000 and 4000;
select * from sales where product_name like 'lap%';
select * from sales where product_name not like '%lap%';
select * from sales where product_name in('phone','laptop');
select * from sales order by sales_date;
select * from sales order by product_name;
select  count( distinct product_name) from sales;
select * from sales where discount IS null;

select min(price) from sales;
select avg(price) from sales;

select * from sales;

select product_name ,count(product_name) from sales group by product_name;

select product_name ,count(product_name) ,sum(price) from sales
group by product_name;

select product_name ,count(product_name) ,sum(price),avg(price) from sales
group by product_name;

-- HAVING CLAUSE--

select product_name ,
count(product_name) as "units sold",
sum(price) as "total sales value",
avg(price)  as 'average price' from sales
group by product_name
having sum(price)>500;


create table Products(product_id int primary key auto_increment,
product_name varchar(100) not null);

select * from products;

insert into Products(product_name) Values("washing machine");
insert into Products(product_name) Values("laptop");
insert into Products(product_name) Values("phone");
insert into Products(product_name) Values("photo frame");
insert into Products(product_name) Values("toaster");


create table sales1(sales_ID int primary key auto_increment ,
product_ID int NOT NULL  ,Qty int, 
price decimal(5,2),discount decimal(5,2));

drop table sales1;

alter table sales1 drop column product_name;
select * from sales1;
select * from products;

insert into sales1(product_ID,Qty,price,discount)
values(10,1,235.77,20);
insert into sales1(product_ID,Qty,price,discount)
values(1,1,250,20);
insert into sales1(product_ID,Qty,price,discount)
values(2,1,200,10);
insert into sales1(product_ID,Qty,price,discount)
values(3,1,350,20);
insert into sales1(product_ID,Qty,price,discount)
values(4,1,250,20);


use dataengineering;
select *from Products as P inner join sales1 as S
on P.product_id=S.product_ID;
select *from Products as P left join sales1 as S
on P.product_id=S.product_ID;
select *from Products as P right join sales1 as S
on P.product_id=S.product_ID;
select *from sales1 as P ,full join Products as S
on P.product_id=S.product_ID;
select * from sales1;
select * from products;

select * from sales1;
select @max_price=MAX(price) from sales1;
select price ,if (max(price)>300,'more','less') from sales1 ;
 set @mrp=200;

create table student_scores(student_ID INT primary key auto_increment,
student_name varchar(100),score decimal(5,2));

insert into student_scores(student_name,score) Values ("saketh",90);
insert into student_scores(student_name,score) Values ("patel",80);
insert into student_scores(student_name,score) Values ("banu",77);
insert into student_scores(student_name,score) Values ("sriram",60);
insert into student_scores(student_name,score) Values ("vikky",50);
insert into student_scores(student_name,score) Values ("venky",40);
select * from student_scores;

select student_name ,
 case 
when score<=100 and score>=90 then ' Grade A'
when score<=89 and score>=70 then 'Grade B'
when score<=69 and score>=60 then 'Grade C'
when score<=59 and score>=50 then 'Grade D'
ELSE 'Grade E'
END as 'Grade'
from student_scores;

create table student_basic_details(student_ID int primary key auto_increment,
student_name varchar(100),mob varchar(10),address varchar(100));
create table student_qualifications(qual_id int primary key auto_increment,
X_marks INT,
XII_marks int,
student_ID int,
foreign key(student_ID) references student_basic_details(student_ID));

select * from student_basic_details;
select * from student_qualifications;

Insert into student_basic_details(student_name,mob,address)
values ('sourab','5587767','xyz');


set @student_IDrbvgfderwas   =@@Identity;

insert into student_qualifications(X_marks,XII_marks,student_ID)
values(90,90,@student_ID);

select * from student_basic_details;
select * from student_qualifications;

drop table student_basic_details;
drop table student_qualifications;

delete from student_basic_details where student_name="sourab";

select SB.student_name,Q.X_marks,Q.XII_marks from 
student_basic_details SB inner join 
student_qualifications Q 
on SB.student_ID=Q.student_ID;


create table customers (customer_ID int  primary key auto_increment,
customer_name varchar(100),
customer_mob varchar(10));
insert into customers(customer_name,customer_mob)
values("sourabh",'9993368881');
insert into customers(customer_name,customer_mob)
values("      deeepak",'9994668881');
insert into customers(customer_name,customer_mob)
values("ram",'9992268881');
insert into customers(customer_name,customer_mob)
values(" ajay          ",'9994448881');
insert into customers(customer_name,customer_mob)
values("      shyam",'9996662221');

select * ,length(customer_name) 'name length',
left(customer_name,3),
right(customer_name,3),
lower(customer_name),
upper(customer_name),

rtrim(customer_name),
ltrim(customer_name),
trim(customer_name)
from customers;

Alter table customers add Insert_date date ;
insert into customers(customer_name,customer_mob,insert_date)
values('radhika',6363637898,current_date());

select *,format(insert_date,'dd-mm-yyyy') from customers;
select * from sales1;
select * from customers;
select *, ceil(235.22),floor(235.22),round(235.22,1) from sales1;

select *, adddate(insert_date,interval 5 month) from customers;
select datediff('2018/09/29','2022/09/29');
select date_format('2024-04-27','%m-%d-%y');
select coalesce(null,null,'sourabh',null);
select abs(-9);
alter table customers add first_name  varchar(100);
alter table customers add middle_name  varchar(100);
alter table customers add last_name  varchar(100);

insert into customers(customer_name,customer_mob,insert_date,first_name,
middle_name,last_name)
values('ram','7272727993',curdate(),'ram','kumar','suresh');
insert into customers(customer_name,customer_mob,insert_date,first_name,
middle_name,last_name)
values('ram','7272727993',curdate(),'ram',null,null);
insert into customers(customer_name,customer_mob,insert_date,first_name,
middle_name,last_name)
values('ram','7272727993',curdate(),null,'k',null);
select * from customers;

select coalesce(first_name,middle_name,last_name,'not available') from customers;

select * ,length(customer_name) 'name_length' from customers;

create PROCEDURE get_sales
AS
  select sum(price) from sales1
  GO;
EXEC  get_sales;
CREATE PROCEDURE SelectAllCustomers
AS
SELECT * FROM Customers;
GO;


  Create  Procedure get_sales @id INT
  AS
  Begin 
  select sum(price) from sales 
  where product_ID=@id
  END
  
  exec get_sales 5
  
select cast(2 as char);
SELECT CAST("2017-08-29" AS DATE);

select cast('saketh' as nchar);
SELECT CAST(3-22 AS SIGNED);

select ifnull(null,'saketh');
select isnull(324546);

select IIF(4>6 ,'saketh', 'patel');

select coalesce(null,null,null,'patel','chennai');
use dataengineering1;
create table something(name varchar(100), age int);
use dataengineering;
create view tabless as select price from sales1 where price>50;

create view mult_table as select price ,student_name from sales1,student_scores;
select * from mult_table;

create index new_index 
on sales1(price);

select * from sales1 use index(new_index);
select * from products;

select product_ID, max(price) from sales1 group by sales_ID;

select * ,max(price) over (partition by product_ID) as max_price from sales1;
-- row number
select * from(select *, row_number() over(partition by product_ID) as rn from sales1) x 
where x.rn<=2 ;

-- rank functin--  

select * from(select *, rank() over(partition by product_ID order by price desc) as rnk 
from sales1) x
where x.rnk<4;

create table employee1_window(emp_id int primary key auto_increment ,emp_name varchar(100),
dept_name varchar(100) ,salary int );
insert into employee1_window(emp_name,dept_name,salary) values('saketh','IT',10000);
insert into employee1_window(emp_name,dept_name,salary) values('vikram','IT',8000);
insert into employee1_window(emp_name,dept_name,salary) values('vasuda','IT',6000);
insert into employee1_window(emp_name,dept_name,salary) values('sanjay','IT',5000);
insert into employee1_window(emp_name,dept_name,salary) values('ibrahim','finance',7000);
insert into employee1_window(emp_name,dept_name,salary) values('chandini','finance',8000);
insert into employee1_window(emp_name,dept_name,salary) values('monica','finance',9000);
insert into employee1_window(emp_name,dept_name,salary) values('maryan','finance',9000);

insert into employee1_window(emp_name,dept_name,salary) values('gautham','admin',8000);
insert into employee1_window(emp_name,dept_name,salary) values('dorvin','admin',8000);
insert into employee1_window(emp_name,dept_name,salary) values('satya','admin',9000);
insert into employee1_window(emp_name,dept_name,salary) values('tejaswini','admin',6000);

insert into employee1_window(emp_name,dept_name,salary) values('ibrahim','finance',7000);
insert into employee1_window(emp_name,dept_name,salary) values('chandini','finance',8000);
insert into employee1_window(emp_name,dept_name,salary) values('monica','finance',9000);
insert into employee1_window(emp_name,dept_name,salary) values('maryan','finance',9000);


select * from employee1_window;

select *, 
rank() over( partition by dept_name order by salary desc) as rnk ,
dense_rank() over(partition by dept_name order by salary desc) as dense_rnk ,
row_number() over(partition by dept_name order by salary desc) rn 
from employee1_window;


select *, lag(salary) over(partition by dept_name order by emp_id) as prev_emp_salary,
lead(salary) over(partition by dept_name order by emp_id) as nex_emp_salary,
ntile(2) over(order by emp_id) as tile
from employee1_window;
select * from employee1_window;

select *, lead(salary) over(partition by dept_name order by emp_id) as nex_emp_salary
from employee1_window;

select * ,ntile(2) over(order by emp_id) as tile from employee1_window;
select now();

select *,max(salary) from employee1_window
group by dept_name;

update employee1_window
set salary=1000
where emp_id=1;

select * from employee1_window;

use dataengineering;
select * from employee1_window
where lower(substring(emp_name,1,1));

select * from employee1_window
group by dept_name;








