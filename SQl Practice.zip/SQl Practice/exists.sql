use  dataengineering1;
create table customers(customer_id int primary key ,
customer_name varchar(100) ,city varchar(100));

insert into customers(customer_id,customer_name,city) values(1,'saketh','hyd');
insert into customers(customer_id,customer_name,city) values(2,'patel','hyd');
insert into customers(customer_id,customer_name,city) values(3,'bhanu','hyd');
insert into customers(customer_id,customer_name,city) values(4,'muni','hyd');
insert into customers(customer_id,customer_name,city) values(5,'sriram','hyd');

create table orders( order_id int primary key,
customer_id int,
product_id int,
order_date date,
foreign key(customer_id) references customers(customer_id));

INSERT INTO orders (order_id, customer_id, product_id, order_date) VALUES
(1, 1, 1, '2024-04-15'),
(2, 2, 3, '2024-04-16'),
(3, 3, 2, '2024-04-17'),
(4, 1, 2, '2024-04-18'),
(5, 4, 1, '2024-04-19'),
(6, 2, 1, '2024-04-20'),
(7, 3, 3, '2024-04-21'),
(8, 5, 2, '2024-04-22'),
(9, 4, 3, '2024-04-23'),
(10, 1, 3, '2024-04-24');


select * from customers;
select * from orders;

select 1 from orders;

select * from customers 
where Exists(select 1 from orders where customers.customer_ID=orders.customer_ID );
select 1 from orders where customers.customer_ID=orders.customer_ID
delete from orders where customer_ID =5;

select * from customers
where customer_ID=Any(select customer_ID from orders);

select * from customers
where not exists (select 0 from orders where customers.customer_ID =orders.customer_ID)










