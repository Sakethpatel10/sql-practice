 create table employee(emp_name varchar(250),emp_id int
 , emp_address text);
 
 insert  into employee(emp_name,emp_address,emp_id)
Values("saketh","hyd",2);
insert  into employee
Values("manu",3,"hyd"),("sonu",4,"chennai");


select  * from employee;

delete from employee;
drop table emp2;

create table emp2(name char(250));
insert  into emp2
Values("~&%$saketh");
select * from emp3;
-- primary key
create table emp3(name char(250),age int ,id int primary key );
insert into emp3
values ("saketh",22,1);
insert into emp3
values ("patel",22,2)	;

create table emp5(emp_id int Foreign key references emp3(id),
name varchar);
insert into emp5
values(1,"saketh");