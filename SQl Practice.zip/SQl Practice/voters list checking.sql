create database election_db;
create schema voters;
create TABLE citizen(citizen_id int primary key not null auto_increment ,citizen_name
varchar(100),aadhar_no varchar(12) unique ,country varchar(10) default
'india');

insert into citizen(citizen_name ,aadhar_no)
values('saketh','99999999999');

insert into citizen(citizen_name ,aadhar_no)
values('patel','9999999999');

select * from citizen;

insert into citizen(citizen_id,citizen_name,aadhar_no)
values(4,'venky','8899999999');
drop table citizen;

create table voters(id int primary key auto_increment not null,
voter_id int unique not null,voter_name  varchar(100)not null  ,
age int check(age>=18) ,mobile_num varchar(10) unique,citizen_id int,
foreign key(citizen_id) references citizen(citizen_id)) ;

insert into voters(voter_id,voter_name,age,mobile_num,citizen_id)
values(100,"saketh",22,"1234567890",100);
insert into voters(voter_id,voter_name,age,mobile_num)
values(101,"vamshi",22,"1234567891");

insert into voters(voter_id,voter_name,age,mobile_num)
values(101,"deepak",17,"124567891");

drop table voters;

select * from citizen;
select * from voters;


update  citizen
set citizen_id=101
where citizen_name="patel";

delete from citizen
where citizen_name="saketh";



